package com.papeleria.ventas.service;

import com.papeleria.ventas.model.Venta;
import com.papeleria.ventas.repository.VentaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentaService {

    private final VentaRepository ventaRepository;

    public VentaService(VentaRepository ventaRepository) {
        this.ventaRepository = ventaRepository;
    }

    public List<Venta> obtenerTodas() {
        return ventaRepository.findAll();
    }

    public Venta buscarPorId(Long id) {
        return ventaRepository.findById(id).orElse(null);
    }

    public Venta registrarVenta(Venta venta) {
        // TODO: Aquí irá la comunicación con Inventario y Facturación usando WebClient
        return ventaRepository.save(venta);
    }
}