package com.papeleria.ventas.dto;

import java.time.LocalDateTime;

public class VentaDTO {

    private Long id;
    private Long idCliente; // Conectará con crm-ms más adelante
    private Double total;
    private LocalDateTime fechaVenta;
    private String estado; // Ej: "COMPLETADA", "PENDIENTE"

    public VentaDTO() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getIdCliente() { return idCliente; }
    public void setIdCliente(Long idCliente) { this.idCliente = idCliente; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public LocalDateTime getFechaVenta() { return fechaVenta; }
    public void setFechaVenta(LocalDateTime fechaVenta) { this.fechaVenta = fechaVenta; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}