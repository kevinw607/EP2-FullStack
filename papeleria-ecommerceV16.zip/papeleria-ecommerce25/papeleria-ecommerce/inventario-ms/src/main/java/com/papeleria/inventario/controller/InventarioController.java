package com.papeleria.inventario.controller;

import com.papeleria.inventario.model.Inventario;
import com.papeleria.inventario.service.InventarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventarios")
public class InventarioController {

    private final InventarioService inventarioService;

    public InventarioController(InventarioService inventarioService) {
        this.inventarioService = inventarioService;
    }

    @GetMapping
    public ResponseEntity<List<Inventario>> listarStock() {
        List<Inventario> stock = inventarioService.obtenerTodos();
        return ResponseEntity.ok(stock);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inventario> obtenerStockPorId(@PathVariable Long id) {
        Inventario inventario = inventarioService.buscarPorId(id);
        if (inventario != null) {
            return ResponseEntity.ok(inventario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Inventario> registrarStock(@RequestBody Inventario inventario) {
        Inventario nuevoStock = inventarioService.guardarInventario(inventario);
        return ResponseEntity.ok(nuevoStock);
    }
}