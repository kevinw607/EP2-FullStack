package com.papeleria.inventario.service;

import com.papeleria.inventario.model.Inventario;
import com.papeleria.inventario.repository.InventarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioService {

    private final InventarioRepository inventarioRepository;

    // Inyección de dependencias segura por constructor
    public InventarioService(InventarioRepository inventarioRepository) {
        this.inventarioRepository = inventarioRepository;
    }

    // Listar todo el stock
    public List<Inventario> obtenerTodos() {
        return inventarioRepository.findAll();
    }

    // Buscar stock de un producto por ID
    public Inventario buscarPorId(Long id) {
        return inventarioRepository.findById(id).orElse(null);
    }

    // Guardar o actualizar stock
    public Inventario guardarInventario(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }
}