package com.papeleria.inventario.repository;

import com.papeleria.inventario.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long> {
    // Más adelante puedes agregar métodos como:
    // Inventario findByCodigoProducto(String codigoProducto);
}