package com.papeleria.facturacion.service;

import com.papeleria.facturacion.model.Factura;
import com.papeleria.facturacion.repository.FacturaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacturacionService {

    private final FacturaRepository facturaRepository;

    public FacturacionService(FacturaRepository facturaRepository) {
        this.facturaRepository = facturaRepository;
    }




    public Factura guardarFactura(Factura factura) {
        return facturaRepository.save(factura);
    }


    public List<Factura> obtenerTodas() {
        return facturaRepository.findAll();
    }

    public Factura buscarPorId(Long id) {
        return facturaRepository.findById(id).orElse(null);
    }


}