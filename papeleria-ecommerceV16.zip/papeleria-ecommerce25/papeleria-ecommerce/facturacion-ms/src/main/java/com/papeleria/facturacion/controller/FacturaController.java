package com.papeleria.facturacion.controller;

import com.papeleria.facturacion.model.Factura;
import com.papeleria.facturacion.service.FacturacionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaController {

    private final FacturacionService facturacionService;

    // Inyección de dependencias por constructor
    public FacturaController(FacturacionService facturacionService) {
        this.facturacionService = facturacionService;
    }

    // 1. POST: Crear una nueva factura
    // Ejemplo de URL: POST http://localhost:808X/api/facturas
    @PostMapping
    public ResponseEntity<Factura> crearFactura(@RequestBody Factura factura) {
        Factura nuevaFactura = facturacionService.guardarFactura(factura);
        return ResponseEntity.ok(nuevaFactura);
    }

    // 2. GET: Listar todas las facturas
    // Ejemplo de URL: GET http://localhost:808X/api/facturas
    @GetMapping
    public ResponseEntity<List<Factura>> listarFacturas() {
        List<Factura> facturas = facturacionService.obtenerTodas();
        return ResponseEntity.ok(facturas);
    }

    // 3. GET: Obtener una factura específica por su ID
    // Ejemplo de URL: GET http://localhost:808X/api/facturas/1
    @GetMapping("/{id}")
    public ResponseEntity<Factura> obtenerFactura(@PathVariable Long id) {
        Factura factura = facturacionService.buscarPorId(id);
        if (factura != null) {
            return ResponseEntity.ok(factura);
        } else {
            return ResponseEntity.notFound().build(); // Devuelve un error 404 si no existe
        }
    }
}