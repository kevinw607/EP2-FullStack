package com.papeleria.crm.controller;

import com.papeleria.crm.model.Cliente;
import com.papeleria.crm.service.CrmService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crm")
public class CrmController {

    private final CrmService crmService;

    public CrmController(CrmService crmService) {
        this.crmService = crmService;
    }

    // GET: http://localhost:808X/api/crm/clientes
    @GetMapping("/clientes")
    public List<Cliente> listarClientes() {
        return crmService.obtenerTodosLosClientes();
    }

    // GET: http://localhost:808X/api/crm/clientes/1
    @GetMapping("/clientes/{id}")
    public ResponseEntity<Cliente> buscarPorId(@PathVariable Long id) {
        return crmService.obtenerClientePorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET: http://localhost:808X/api/crm/clientes/rut/12345678-9
    @GetMapping("/clientes/rut/{rut}")
    public ResponseEntity<Cliente> buscarPorRut(@PathVariable String rut) {
        return crmService.obtenerClientePorRut(rut)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST: http://localhost:808X/api/crm/clientes
    @PostMapping("/clientes")
    public ResponseEntity<Cliente> registrarCliente(@RequestBody Cliente cliente) {
        return new ResponseEntity<>(crmService.guardarCliente(cliente), HttpStatus.CREATED);
    }

    // PUT: http://localhost:808X/api/crm/clientes/1
    @PutMapping("/clientes/{id}")
    public ResponseEntity<Cliente> actualizarCliente(@PathVariable Long id, @RequestBody Cliente datosActualizados) {
        return crmService.obtenerClientePorId(id)
                .map(clienteExistente -> {
                    clienteExistente.setNombre(datosActualizados.getNombre());
                    clienteExistente.setApellido(datosActualizados.getApellido());
                    clienteExistente.setEmail(datosActualizados.getEmail());
                    clienteExistente.setTelefono(datosActualizados.getTelefono());
                    clienteExistente.setDireccionEnvio(datosActualizados.getDireccionEnvio());
                    return ResponseEntity.ok(crmService.guardarCliente(clienteExistente));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE: http://localhost:808X/api/crm/clientes/1
    @DeleteMapping("/clientes/{id}")
    public ResponseEntity<Void> eliminarCliente(@PathVariable Long id) {
        crmService.eliminarCliente(id);
        return ResponseEntity.noContent().build();
    }
}