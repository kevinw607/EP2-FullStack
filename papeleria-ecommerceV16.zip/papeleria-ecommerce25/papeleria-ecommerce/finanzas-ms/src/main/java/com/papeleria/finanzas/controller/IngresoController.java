package com.papeleria.finanzas.controller;

import com.papeleria.finanzas.model.Ingreso;
import com.papeleria.finanzas.dto.IngresoDTO;
import com.papeleria.finanzas.service.IngresoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/finanzas")
public class IngresoController {

    private final IngresoService ingresoService;

    public IngresoController(IngresoService ingresoService) {
        this.ingresoService = ingresoService;
    }

    @GetMapping
    public List<Ingreso> listarIngresos() {
        return ingresoService.obtenerTodos();
    }


    @PostMapping
    public ResponseEntity<Ingreso> crearIngreso(@RequestBody IngresoDTO ingresoDTO) {
        try {
            Ingreso nuevoIngreso = ingresoService.registrarIngreso(ingresoDTO);
            return ResponseEntity.ok(nuevoIngreso);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}