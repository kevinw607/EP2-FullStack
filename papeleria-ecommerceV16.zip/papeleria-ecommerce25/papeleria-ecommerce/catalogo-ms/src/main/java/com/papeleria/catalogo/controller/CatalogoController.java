package com.papeleria.catalogo.controller;

import com.papeleria.catalogo.model.Categoria;
import com.papeleria.catalogo.model.Producto;
import com.papeleria.catalogo.service.CatalogoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/catalogo")
public class CatalogoController {

    private final CatalogoService catalogoService;

    // Inyectamos el servicio
    public CatalogoController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    // --- Endpoints de Productos ---

    // GET: http://localhost:808X/api/catalogo/productos
    @GetMapping("/productos")
    public List<Producto> listarProductos() {
        return catalogoService.obtenerTodosLosProductos();
    }

    // GET: http://localhost:808X/api/catalogo/productos/1
    @GetMapping("/productos/{id}")
    public ResponseEntity<Producto> buscarProducto(@PathVariable Long id) {
        return catalogoService.obtenerProductoPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build()); // Retorna error 404 si no existe
    }

    // GET: http://localhost:808X/api/catalogo/productos/categoria/2
    @GetMapping("/productos/categoria/{categoriaId}")
    public List<Producto> listarPorCategoria(@PathVariable Long categoriaId) {
        return catalogoService.obtenerProductosPorCategoria(categoriaId);
    }

    // POST: http://localhost:808X/api/catalogo/productos
    @PostMapping("/productos")
    public ResponseEntity<Producto> registrarProducto(@RequestBody Producto producto) {
        return new ResponseEntity<>(catalogoService.guardarProducto(producto), HttpStatus.CREATED); // Retorna código 201 (Creado)
    }

    // DELETE: http://localhost:808X/api/catalogo/productos/1
    @DeleteMapping("/productos/{id}")
    public ResponseEntity<Void> borrarProducto(@PathVariable Long id) {
        catalogoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }

    // --- Endpoints de Categorías ---

    // GET: http://localhost:808X/api/catalogo/categorias
    @GetMapping("/categorias")
    public List<Categoria> listarCategorias() {
        return catalogoService.obtenerTodasLasCategorias();
    }

    // POST: http://localhost:808X/api/catalogo/categorias
    @PostMapping("/categorias")
    public ResponseEntity<Categoria> registrarCategoria(@RequestBody Categoria categoria) {
        return new ResponseEntity<>(catalogoService.guardarCategoria(categoria), HttpStatus.CREATED);
    }
}