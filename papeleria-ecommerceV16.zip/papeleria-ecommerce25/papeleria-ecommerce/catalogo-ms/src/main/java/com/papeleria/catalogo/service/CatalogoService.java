package com.papeleria.catalogo.service;

import com.papeleria.catalogo.model.Categoria;
import com.papeleria.catalogo.model.Producto;
import com.papeleria.catalogo.repository.CategoriaRepository;
import com.papeleria.catalogo.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CatalogoService {

    // 1. Inyectamos los repositorios
    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;

    public CatalogoService(ProductoRepository productoRepository, CategoriaRepository categoriaRepository) {
        this.productoRepository = productoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    // 2. Métodos para manejar Productos
    public List<Producto> obtenerTodosLosProductos() {
        return productoRepository.findAll(); // Usa el superpoder del repositorio
    }

    public Optional<Producto> obtenerProductoPorId(Long id) {
        return productoRepository.findById(id);
    }

    public List<Producto> obtenerProductosPorCategoria(Long categoriaId) {
        return productoRepository.findByCategoriaId(categoriaId); // Nuestro método personalizado
    }

    public Producto guardarProducto(Producto producto) {
        // Aquí podríamos poner reglas, ej: if (producto.getPrecioUnitario() < 0) throw Exception...
        return productoRepository.save(producto);
    }

    public void eliminarProducto(Long id) {
        productoRepository.deleteById(id);
    }

    // 3. Métodos para manejar Categorías
    public List<Categoria> obtenerTodasLasCategorias() {
        return categoriaRepository.findAll();
    }

    public Categoria guardarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }
}