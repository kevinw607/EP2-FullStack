package com.papeleria.seguridad.service;

import com.papeleria.seguridad.model.Usuario;
import com.papeleria.seguridad.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    // Inyección de dependencias por constructor
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // Listar todos los usuarios registrados
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    // Buscar un usuario específico
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    // Registrar un nuevo usuario en la base de datos
    public Usuario registrarUsuario(Usuario usuario) {
        // TODO: Aquí más adelante agregaremos la encriptación de la contraseña con BCrypt
        return usuarioRepository.save(usuario);
    }
}