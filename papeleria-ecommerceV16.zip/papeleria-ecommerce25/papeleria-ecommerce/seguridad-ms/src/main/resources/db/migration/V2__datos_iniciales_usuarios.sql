INSERT INTO usuarios (username, password, rol)VALUES
       ('admin', 'admin123', 'ADMIN'),
       ('pablo', 'pablo2026', 'USER'),
       ('jefe_local', 'admin_local_26', 'ADMIN'),
       ('soporte_tienda', 'helpdesk123', 'USER'),
       ('carlos_soto', 'carlos1234', 'USER'),
       ('ana_valdes', 'secreto456', 'USER'),
       ('camila_reyes', 'cliente_frecuente', 'USER'),
       ('vendedor_01', 'ventas2026', 'USER');