package com.papeleria.notificaciones.controller;

import com.papeleria.notificaciones.model.RegistroNotificacion;
import com.papeleria.notificaciones.service.NotificacionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    // GET: http://localhost:808X/api/notificaciones/historial
    @GetMapping("/historial")
    public List<RegistroNotificacion> verHistorial() {
        return notificacionService.obtenerHistorial();
    }

    // POST: http://localhost:808X/api/notificaciones/enviar
    @PostMapping("/enviar")
    public ResponseEntity<RegistroNotificacion> enviarNotificacion(@RequestBody RegistroNotificacion peticion) {
        RegistroNotificacion resultado = notificacionService.procesarEnvio(peticion);
        return new ResponseEntity<>(resultado, HttpStatus.CREATED);
    }
}