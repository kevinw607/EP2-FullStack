package com.papeleria.notificaciones.service;

import com.papeleria.notificaciones.model.RegistroNotificacion;
import com.papeleria.notificaciones.repository.NotificacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;

    public NotificacionService(NotificacionRepository notificacionRepository) {
        this.notificacionRepository = notificacionRepository;
    }

    public List<RegistroNotificacion> obtenerHistorial() {
        return notificacionRepository.findAll();
    }

    public RegistroNotificacion procesarEnvio(RegistroNotificacion notificacion) {

        System.out.println("--- SIMULANDO ENVÍO DE CORREO ---");
        System.out.println("Para: " + notificacion.getDestinatario());
        System.out.println("Asunto: " + notificacion.getAsunto());
        System.out.println("---------------------------------");

        // Simulamos que el envío fue exitoso
        notificacion.setEstado("ENVIADO");

        // Guardamos el registro histórico en la base de datos
        return notificacionRepository.save(notificacion);
    }
}