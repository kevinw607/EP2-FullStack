package com.papeleria.precios.service;

import com.papeleria.precios.model.Precio;
import com.papeleria.precios.dto.PrecioDTO;
import com.papeleria.precios.repository.PrecioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PrecioService {

    private final PrecioRepository precioRepository;

    public PrecioService(PrecioRepository precioRepository) {
        this.precioRepository = precioRepository;
    }

    public List<Precio> obtenerTodos() {
        return precioRepository.findAll();
    }

    public Optional<Precio> obtenerPorProductoId(Long productoId) {
        return precioRepository.findByProductoId(productoId);
    }

    public Precio guardarPrecio(PrecioDTO precioDTO) {

        Optional<Precio> precioExistente = precioRepository.findByProductoId(precioDTO.getProductoId());

        Precio precio;
        if (precioExistente.isPresent()) {
            precio = precioExistente.get();
        } else {
            precio = new Precio();
            precio.setProductoId(precioDTO.getProductoId());
        }

        precio.setPrecioOferta(precioDTO.getPrecioOferta());
        precio.setDescripcionDescuento(precioDTO.getDescripcionDescuento());

        return precioRepository.save(precio);
    }
}