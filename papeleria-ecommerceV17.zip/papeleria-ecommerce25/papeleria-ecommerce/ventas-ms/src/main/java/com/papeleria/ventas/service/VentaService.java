package com.papeleria.ventas.service;


import com.papeleria.ventas.model.Venta;
import com.papeleria.ventas.repository.VentaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VentaService {

    private final VentaRepository ventaRepository;
    private final RestTemplate restTemplate;

    public VentaService(VentaRepository ventaRepository, RestTemplate restTemplate) {
        this.ventaRepository = ventaRepository;
        this.restTemplate = restTemplate;
    }

    public List<Venta> obtenerTodas() {
        return ventaRepository.findAll();
    }

    public Venta buscarPorId(Long id) {
        return ventaRepository.findById(id).orElse(null);
    }

    public Venta registrarVenta(Venta venta) {
        // 1. Guardamos la venta en la base de datos de ventas
        Venta nuevaVenta = ventaRepository.save(venta);

        // 2. Le mandamos los datos al microservicio de Inventario
        try {
            String urlInventario = "http://localhost:8086/api/inventarios";

            // Preparamos los datos con los nombres exactos que espera tu Inventario
            Map<String, Object> datosInventario = new HashMap<>();
            datosInventario.put("productoId", venta.getProductoId());
            datosInventario.put("cantidad", -venta.getCantidad());

            // Ejecutamos la llamada
            restTemplate.postForObject(urlInventario, datosInventario, Object.class);
            System.out.println("Éxito: Se actualizó el stock en Inventario.");
        } catch (Exception e) {
            System.out.println("Error al conectar con Inventario: " + e.getMessage());
        }

        return nuevaVenta;
    }
}