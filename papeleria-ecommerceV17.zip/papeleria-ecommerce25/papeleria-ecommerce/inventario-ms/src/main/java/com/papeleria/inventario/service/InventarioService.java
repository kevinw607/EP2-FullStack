package com.papeleria.inventario.service;

import com.papeleria.inventario.model.Inventario;
import com.papeleria.inventario.repository.InventarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioService {

    private final InventarioRepository inventarioRepository;

    public InventarioService(InventarioRepository inventarioRepository) {
        this.inventarioRepository = inventarioRepository;
    }

    public List<Inventario> obtenerTodos() {
        return inventarioRepository.findAll();
    }

    public Inventario buscarPorId(Long id) {
        return inventarioRepository.findById(id).orElse(null);
    }

    public Inventario guardarInventario(Inventario inventarioEntrante) {
        // 1. Traemos todo el stock actual
        List<Inventario> stockActual = inventarioRepository.findAll();


        for (Inventario item : stockActual) {
            if (item.getProductoId().equals(inventarioEntrante.getProductoId())) {

                // Simplemente restamos la cantidad que llega desde Ventas
                // Sin importar si el resultado final es 100, 0, o -50
                int nuevaCantidad = item.getCantidad() - inventarioEntrante.getCantidad();

                item.setCantidad(nuevaCantidad);
                return inventarioRepository.save(item);
            }
        }


        return inventarioRepository.save(inventarioEntrante);
    }
}

//{
//  "clienteId": 1,
//  "productoId": 3,
//  "cantidad": 50
//}

//POST http://localhost:8090/api/ventas
//GET http://localhost:8086/api/inventarios