INSERT INTO inventario (producto_id, cantidad) VALUES (1, 50);
INSERT INTO inventario (producto_id, cantidad) VALUES (2, 200);