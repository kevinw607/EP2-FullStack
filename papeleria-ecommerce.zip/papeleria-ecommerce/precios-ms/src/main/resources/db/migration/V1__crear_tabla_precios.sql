CREATE TABLE precios (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  producto_id BIGINT NOT NULL,
  precio_base DOUBLE NOT NULL,
  descuento DOUBLE DEFAULT 0.0
);