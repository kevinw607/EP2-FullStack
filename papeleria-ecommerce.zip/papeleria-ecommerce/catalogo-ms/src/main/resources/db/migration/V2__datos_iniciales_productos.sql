INSERT INTO productos (nombre, precio) VALUES ('Cuaderno Pro', 2500.0);
INSERT INTO productos (nombre, precio) VALUES ('Lápiz Pasta Azul', 500.0);