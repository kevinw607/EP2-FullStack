INSERT INTO facturas (cliente_id, monto_total) VALUES (1, 15500.0);
INSERT INTO facturas (cliente_id, monto_total) VALUES (2, 8990.0);