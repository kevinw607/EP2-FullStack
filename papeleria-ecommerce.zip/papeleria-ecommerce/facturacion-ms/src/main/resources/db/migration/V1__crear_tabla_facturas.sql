CREATE TABLE facturas (
     id BIGINT AUTO_INCREMENT PRIMARY KEY,
     cliente_id BIGINT NOT NULL,
     monto_total DOUBLE NOT NULL,
     fecha_emision TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);