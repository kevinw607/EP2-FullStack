package com.papeleria.notificaciones;

public class NotificacionesApplication {
}
