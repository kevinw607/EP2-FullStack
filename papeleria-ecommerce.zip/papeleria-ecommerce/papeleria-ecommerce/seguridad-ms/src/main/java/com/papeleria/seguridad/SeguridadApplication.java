package com.papeleria.seguridad;

public class SeguridadApplication {
}
