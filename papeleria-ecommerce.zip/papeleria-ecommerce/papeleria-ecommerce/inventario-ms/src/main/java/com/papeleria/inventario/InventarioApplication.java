package com.papeleria.inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // <--- Aquí está la etiqueta mágica
public class InventarioApplication {

    public static void main(String[] args) {
        // Esta línea arranca todo el framework de Spring
        SpringApplication.run(InventarioApplication.class, args);
    }
}