package com.papeleria.finanzas;

public class FinanzasApplcation {
}
