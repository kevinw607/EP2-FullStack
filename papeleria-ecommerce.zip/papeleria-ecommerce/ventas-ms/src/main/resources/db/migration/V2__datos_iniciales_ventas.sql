INSERT INTO ventas (cliente_id, total, estado) VALUES (1, 12500.0, 'COMPLETADO');
INSERT INTO ventas (cliente_id, total, estado) VALUES (2, 5400.0, 'PENDIENTE');