package com.papeleria.facturacion.model;

public class FacturaDTO {
    private String numeroFactura;
    private Double montoTotal;

    public FacturaDTO() {}

    public String getNumeroFactura() { return numeroFactura; }
    public void setNumeroFactura(String numeroFactura) { this.numeroFactura = numeroFactura; }
    public Double getMontoTotal() { return montoTotal; }
    public void setMontoTotal(Double montoTotal) { this.montoTotal = montoTotal; }
}