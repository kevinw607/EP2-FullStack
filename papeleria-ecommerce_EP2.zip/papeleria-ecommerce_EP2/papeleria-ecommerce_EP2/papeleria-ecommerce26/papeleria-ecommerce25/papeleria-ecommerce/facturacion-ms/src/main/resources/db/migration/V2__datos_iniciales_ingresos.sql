INSERT INTO facturas (numero_factura, monto_total) VALUES ('FAC-2026-001', 15490.0);
INSERT INTO facturas (numero_factura, monto_total) VALUES ('FAC-2026-002', 8990.0);