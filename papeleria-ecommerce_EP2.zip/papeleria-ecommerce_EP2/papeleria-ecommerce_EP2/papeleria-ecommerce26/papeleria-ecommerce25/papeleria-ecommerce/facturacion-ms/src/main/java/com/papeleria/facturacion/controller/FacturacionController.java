package com.papeleria.facturacion.controller;

import com.papeleria.facturacion.entity.Factura;
import com.papeleria.facturacion.model.FacturaDTO;
import com.papeleria.facturacion.service.FacturacionService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/facturacion")
public class FacturacionController {
    private final FacturacionService facturacionService;

    public FacturacionController(FacturacionService facturacionService) {
        this.facturacionService = facturacionService;
    }

    @GetMapping
    public List<Factura> listar() {
        return facturacionService.obtenerTodas();
    }

    @PostMapping
    public Factura crear(@RequestBody FacturaDTO dto) {
        return facturacionService.generarFactura(dto);
    }
}