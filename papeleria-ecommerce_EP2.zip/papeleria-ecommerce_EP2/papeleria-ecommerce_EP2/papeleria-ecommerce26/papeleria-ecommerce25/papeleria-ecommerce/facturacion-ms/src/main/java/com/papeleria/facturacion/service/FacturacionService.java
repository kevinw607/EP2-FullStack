package com.papeleria.facturacion.service;

import com.papeleria.facturacion.entity.Factura;
import com.papeleria.facturacion.model.FacturaDTO;
import com.papeleria.facturacion.repository.FacturaRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class FacturacionService {
    private final FacturaRepository facturaRepository;

    public FacturacionService(FacturaRepository facturaRepository) {
        this.facturaRepository = facturaRepository;
    }

    public List<Factura> obtenerTodas() {
        return facturaRepository.findAll();
    }

    public Factura generarFactura(FacturaDTO dto) {
        Factura factura = new Factura();
        factura.setNumeroFactura(dto.getNumeroFactura());
        factura.setMontoTotal(dto.getMontoTotal());
        factura.setFechaEmision(LocalDateTime.now());
        return facturaRepository.save(factura);
    }
}