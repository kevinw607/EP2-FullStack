package com.papeleria.inventario.controller;

import com.papeleria.inventario.entity.Inventario;
import com.papeleria.inventario.model.InventarioDTO;
import com.papeleria.inventario.service.InventarioService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {
    private final InventarioService inventarioService;

    public InventarioController(InventarioService inventarioService) {
        this.inventarioService = inventarioService;
    }

    @GetMapping
    public List<Inventario> listar() {
        return inventarioService.obtenerTodos();
    }

    @PostMapping
    public Inventario agregar(@RequestBody InventarioDTO dto) {
        return inventarioService.agregarStock(dto);
    }
}