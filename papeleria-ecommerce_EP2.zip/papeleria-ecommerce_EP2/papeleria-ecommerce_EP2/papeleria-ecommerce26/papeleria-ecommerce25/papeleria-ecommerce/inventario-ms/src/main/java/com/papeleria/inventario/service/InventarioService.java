package com.papeleria.inventario.service;

import com.papeleria.inventario.entity.Inventario;
import com.papeleria.inventario.model.InventarioDTO;
import com.papeleria.inventario.repository.InventarioRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class InventarioService {
    private final InventarioRepository inventarioRepository;

    public InventarioService(InventarioRepository inventarioRepository) {
        this.inventarioRepository = inventarioRepository;
    }

    public List<Inventario> obtenerTodos() {
        return inventarioRepository.findAll();
    }

    public Inventario agregarStock(InventarioDTO dto) {
        Optional<Inventario> existente = inventarioRepository.findByProductoId(dto.getProductoId());

        Inventario inventario;
        if (existente.isPresent()) {
            inventario = existente.get();
            inventario.setCantidad(inventario.getCantidad() + dto.getCantidad());
        } else {
            inventario = new Inventario();
            inventario.setProductoId(dto.getProductoId());
            inventario.setCantidad(dto.getCantidad());
            inventario.setBodega(dto.getBodega());
        }
        return inventarioRepository.save(inventario);
    }
}