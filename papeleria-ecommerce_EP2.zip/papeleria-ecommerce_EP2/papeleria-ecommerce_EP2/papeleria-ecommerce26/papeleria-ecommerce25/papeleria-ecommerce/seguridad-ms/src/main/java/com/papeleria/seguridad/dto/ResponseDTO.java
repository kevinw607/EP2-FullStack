package com.papeleria.seguridad.dto;

public class ResponseDTO {

    private String respuestaText;
    private Integer respuestaInteger;

    public String getRespuestaText() {
        return respuestaText;
    }

    public void setRespuestaText(String respuestaText) {
        this.respuestaText = respuestaText;
    }

    public Integer getRespuestaInteger() {
        return respuestaInteger;
    }

    public void setRespuestaInteger(Integer respuestaInteger) {
        this.respuestaInteger = respuestaInteger;
    }
}