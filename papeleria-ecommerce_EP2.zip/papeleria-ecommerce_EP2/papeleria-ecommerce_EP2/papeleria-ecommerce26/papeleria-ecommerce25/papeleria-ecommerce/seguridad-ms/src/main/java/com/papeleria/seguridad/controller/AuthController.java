package com.papeleria.seguridad.controller;

import com.papeleria.seguridad.dto.LoginJWTDTO;
import com.papeleria.seguridad.dto.ResponseDTO;
import com.papeleria.seguridad.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(
            AuthService authService
    ) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseDTO login(
            @RequestBody LoginJWTDTO request
    ) {
        return authService.validar(request);
    }
}