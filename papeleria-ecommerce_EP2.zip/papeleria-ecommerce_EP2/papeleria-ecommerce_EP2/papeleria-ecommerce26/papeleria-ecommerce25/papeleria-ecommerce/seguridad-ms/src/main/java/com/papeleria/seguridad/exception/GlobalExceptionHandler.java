package com.papeleria.seguridad.exception;

import com.papeleria.seguridad.dto.ErrorResponse;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            MethodArgumentNotValidException.class
    )
    public ResponseEntity<ErrorResponse>
    validationException(
            MethodArgumentNotValidException ex
    ) {

        ErrorResponse error =
                new ErrorResponse();

        error.setMensaje(
                "Error de validación"
        );

        error.setDetalle(
                ex.getMessage()
        );

        error.setStatus(400);

        error.setTimeStamp(
                LocalDateTime.now()
        );

        return ResponseEntity
                .badRequest()
                .body(error);
    }

    @ExceptionHandler(
            EntityNotFoundException.class
    )
    public ResponseEntity<ErrorResponse>
    notFoundException(
            EntityNotFoundException ex
    ) {

        ErrorResponse error =
                new ErrorResponse();

        error.setMensaje(
                "Recurso no encontrado"
        );

        error.setDetalle(
                ex.getMessage()
        );

        error.setStatus(404);

        error.setTimeStamp(
                LocalDateTime.now()
        );

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(error);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse>
    generalException(
            Exception ex
    ) {

        ErrorResponse error =
                new ErrorResponse();

        error.setMensaje(
                "Error interno"
        );

        error.setDetalle(
                ex.getMessage()
        );

        error.setStatus(500);

        error.setTimeStamp(
                LocalDateTime.now()
        );

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(error);
    }
}