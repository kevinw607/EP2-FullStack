INSERT INTO usuarios (username, password, rol) VALUES ('admin', 'admin123', 'ADMIN');
INSERT INTO usuarios (username, password, rol) VALUES ('pablo', 'pablo2026', 'USER');