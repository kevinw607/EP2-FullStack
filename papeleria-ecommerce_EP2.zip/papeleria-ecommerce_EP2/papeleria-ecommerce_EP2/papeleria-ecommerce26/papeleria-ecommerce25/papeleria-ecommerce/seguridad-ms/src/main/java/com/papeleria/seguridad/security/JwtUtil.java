package com.papeleria.seguridad.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class JwtUtil {

    private final String SECRET =
            "papeleria_secret_key_2026";

    public String generateToken(
            String username,
            String rol
    ) {

        return JWT.create()
                .withSubject(username)
                .withClaim(
                        "roles",
                        List.of("ROLE_" + rol)
                )
                .withExpiresAt(
                        new Date(
                                System.currentTimeMillis()
                                        + 900000
                        )
                )
                .sign(
                        Algorithm.HMAC256(SECRET)
                );
    }

    public String getSecret() {
        return SECRET;
    }
}