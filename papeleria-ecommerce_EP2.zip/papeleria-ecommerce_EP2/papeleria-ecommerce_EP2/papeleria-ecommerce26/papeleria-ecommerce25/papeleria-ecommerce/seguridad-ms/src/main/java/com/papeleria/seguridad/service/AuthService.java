package com.papeleria.seguridad.service;

import com.papeleria.seguridad.dto.LoginJWTDTO;
import com.papeleria.seguridad.dto.ResponseDTO;
import com.papeleria.seguridad.entity.Usuario;
import com.papeleria.seguridad.repository.UsuarioRepository;
import com.papeleria.seguridad.security.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public AuthService(
            UsuarioRepository usuarioRepository,
            JwtUtil jwtUtil,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    public ResponseDTO validar(LoginJWTDTO request) {

        ResponseDTO response =
                new ResponseDTO();

        Usuario usuario =
                usuarioRepository
                        .findByUsername(
                                request.getUsername()
                        )
                        .orElse(null);

        if (usuario == null) {

            response.setRespuestaInteger(1);
            response.setRespuestaText(
                    "Usuario no encontrado"
            );

            return response;
        }

        if (passwordEncoder.matches(
                request.getPassword(),
                usuario.getPassword()
        )) {

            String token =
                    jwtUtil.generateToken(
                            usuario.getUsername(),
                            usuario.getRol()
                    );

            response.setRespuestaInteger(0);
            response.setRespuestaText(token);

            return response;
        }

        response.setRespuestaInteger(2);
        response.setRespuestaText(
                "Credenciales inválidas"
        );

        return response;
    }
}