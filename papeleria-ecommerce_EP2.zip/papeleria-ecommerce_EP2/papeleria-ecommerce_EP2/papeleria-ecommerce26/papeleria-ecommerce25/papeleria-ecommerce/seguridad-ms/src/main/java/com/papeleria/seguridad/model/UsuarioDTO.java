package com.papeleria.seguridad.model;

public class UsuarioDTO {
    private String username;
    private String password;
    private String rol;

    public UsuarioDTO() {}

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
}