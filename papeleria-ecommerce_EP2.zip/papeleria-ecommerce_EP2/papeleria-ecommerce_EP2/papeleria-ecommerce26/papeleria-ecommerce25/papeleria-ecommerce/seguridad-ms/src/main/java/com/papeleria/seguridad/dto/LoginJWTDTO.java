package com.papeleria.seguridad.dto;

public class LoginJWTDTO {

    private String username;
    private String password;

    public LoginJWTDTO() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}