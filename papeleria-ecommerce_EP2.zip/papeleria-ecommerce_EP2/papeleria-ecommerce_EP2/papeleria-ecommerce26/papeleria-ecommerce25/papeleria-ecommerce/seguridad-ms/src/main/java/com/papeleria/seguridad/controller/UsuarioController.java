package com.papeleria.seguridad.controller;

import com.papeleria.seguridad.entity.Usuario;
import com.papeleria.seguridad.model.UsuarioDTO;
import com.papeleria.seguridad.service.UsuarioService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public List<Usuario> listar() {
        return usuarioService.obtenerTodos();
    }

    @PostMapping
    public Usuario registrar(@RequestBody UsuarioDTO dto) {
        return usuarioService.crearUsuario(dto);
    }
    @GetMapping("/test")
    public String test() {
        return "JWT funcionando";
    }
}
