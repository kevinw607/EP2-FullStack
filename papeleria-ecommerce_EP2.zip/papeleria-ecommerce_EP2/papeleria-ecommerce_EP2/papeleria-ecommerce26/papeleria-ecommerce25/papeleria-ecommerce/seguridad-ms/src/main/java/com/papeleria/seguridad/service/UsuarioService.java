package com.papeleria.seguridad.service;

import com.papeleria.seguridad.entity.Usuario;
import com.papeleria.seguridad.model.UsuarioDTO;
import com.papeleria.seguridad.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    public Usuario crearUsuario(UsuarioDTO dto) {

        Usuario usuario = new Usuario();

        usuario.setUsername(dto.getUsername());

        usuario.setPassword(
                passwordEncoder.encode(
                        dto.getPassword()
                )
        );

        usuario.setRol(
                dto.getRol() != null
                        ? dto.getRol()
                        : "USER"
        );

        return usuarioRepository.save(usuario);
    }
}
