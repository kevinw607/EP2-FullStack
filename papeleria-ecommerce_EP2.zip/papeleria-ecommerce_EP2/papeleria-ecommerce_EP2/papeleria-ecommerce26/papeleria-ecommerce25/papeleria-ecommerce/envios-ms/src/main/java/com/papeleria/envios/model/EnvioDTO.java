package com.papeleria.envios.model;

public class EnvioDTO {
    private String direccion;
    private String estado;
    private String seguimiento;

    public EnvioDTO() {}

    public EnvioDTO(String direccion, String estado, String seguimiento) {
        this.direccion = direccion;
        this.estado = estado;
        this.seguimiento = seguimiento;
    }


    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getSeguimiento() { return seguimiento; }
    public void setSeguimiento(String seguimiento) { this.seguimiento = seguimiento; }
}