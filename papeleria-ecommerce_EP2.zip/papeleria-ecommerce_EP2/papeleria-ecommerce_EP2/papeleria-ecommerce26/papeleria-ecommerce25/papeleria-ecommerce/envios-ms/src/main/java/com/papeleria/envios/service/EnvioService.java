package com.papeleria.envios.service;

import com.papeleria.envios.entity.Envio;
import com.papeleria.envios.model.EnvioDTO;
import com.papeleria.envios.repository.EnvioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnvioService {

    private final EnvioRepository envioRepository;

    public EnvioService(EnvioRepository envioRepository) {
        this.envioRepository = envioRepository;
    }

    public List<Envio> obtenerTodos() {
        return envioRepository.findAll();
    }

    public Optional<Envio> obtenerPorId(Long id) {
        return envioRepository.findById(id);
    }

    public Envio crearEnvio(EnvioDTO envioDTO) {
        Envio envio = new Envio();
        envio.setDireccion(envioDTO.getDireccion());

        envio.setEstado(envioDTO.getEstado() != null ? envioDTO.getEstado() : "PREPARACION");
        envio.setSeguimiento(envioDTO.getSeguimiento());
        return envioRepository.save(envio);
    }

    public Optional<Envio> actualizarEstado(Long id, String nuevoEstado) {
        return envioRepository.findById(id).map(envio -> {
            envio.setEstado(nuevoEstado);
            return envioRepository.save(envio);
        });
    }
}