package com.papeleria.catalogo.exception;

public class GlobalExceptionHandler {
}
