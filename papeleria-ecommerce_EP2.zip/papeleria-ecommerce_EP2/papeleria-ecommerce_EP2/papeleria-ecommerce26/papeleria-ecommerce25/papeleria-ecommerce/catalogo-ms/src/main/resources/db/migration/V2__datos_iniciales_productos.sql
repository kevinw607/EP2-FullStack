INSERT INTO productos (nombre, precio) VALUES ('Cuaderno Universitario Matte', 2490.0);
INSERT INTO productos (nombre, precio) VALUES ('Lápiz Pasta Azul Bic (12 un)', 1990.0);