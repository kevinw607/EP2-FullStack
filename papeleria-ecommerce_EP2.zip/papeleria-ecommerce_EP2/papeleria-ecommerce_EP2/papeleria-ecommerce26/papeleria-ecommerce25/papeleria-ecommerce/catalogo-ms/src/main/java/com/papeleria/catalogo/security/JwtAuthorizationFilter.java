package com.papeleria.catalogo.security;

public class JwtAuthorizationFilter {
}
