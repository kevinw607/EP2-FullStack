package com.papeleria.catalogo.config;

public class SecurityConfig {
}
