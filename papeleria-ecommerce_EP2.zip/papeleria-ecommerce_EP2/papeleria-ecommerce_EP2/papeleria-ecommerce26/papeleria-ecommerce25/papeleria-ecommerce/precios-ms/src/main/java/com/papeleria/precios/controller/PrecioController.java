package com.papeleria.precios.controller;

import com.papeleria.precios.entity.Precio;
import com.papeleria.precios.model.PrecioDTO;
import com.papeleria.precios.service.PrecioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/precios")
public class PrecioController {

    private final PrecioService precioService;

    public PrecioController(PrecioService precioService) {
        this.precioService = precioService;
    }

    @GetMapping
    public List<Precio> listarTodos() {
        return precioService.obtenerTodos();
    }

    @GetMapping("/producto/{productoId}")
    public ResponseEntity<Precio> buscarPorProducto(@PathVariable Long productoId) {
        return precioService.obtenerPorProductoId(productoId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Precio registrarOActualizarPrecio(@RequestBody PrecioDTO precioDTO) {
        return precioService.guardarPrecio(precioDTO);
    }
}