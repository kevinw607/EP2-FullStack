package com.papeleria.ventas.controller;

import com.papeleria.ventas.entity.Venta;
import com.papeleria.ventas.model.VentaDTO;
import com.papeleria.ventas.service.VentaService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {
    private final VentaService ventaService;

    public VentaController(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    @GetMapping
    public List<Venta> listar() {
        return ventaService.obtenerTodas();
    }

    @PostMapping
    public Venta crear(@RequestBody VentaDTO dto) {
        return ventaService.procesarVenta(dto);
    }
}