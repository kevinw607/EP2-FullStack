INSERT INTO ventas (cliente_id, producto_id, cantidad) VALUES (1, 1, 3);
INSERT INTO ventas (cliente_id, producto_id, cantidad) VALUES (2, 2, 5);