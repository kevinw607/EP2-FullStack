package com.papeleria.ventas.service;

import com.papeleria.ventas.entity.Venta;
import com.papeleria.ventas.model.VentaDTO;
import com.papeleria.ventas.repository.VentaRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class VentaService {
    private final VentaRepository ventaRepository;

    public VentaService(VentaRepository ventaRepository) {
        this.ventaRepository = ventaRepository;
    }

    public List<Venta> obtenerTodas() {
        return ventaRepository.findAll();
    }

    public Venta procesarVenta(VentaDTO dto) {
        Venta venta = new Venta();
        venta.setClienteId(dto.getClienteId());
        venta.setProductoId(dto.getProductoId());
        venta.setCantidad(dto.getCantidad());
        venta.setFechaVenta(LocalDateTime.now());

        return ventaRepository.save(venta);
    }
}