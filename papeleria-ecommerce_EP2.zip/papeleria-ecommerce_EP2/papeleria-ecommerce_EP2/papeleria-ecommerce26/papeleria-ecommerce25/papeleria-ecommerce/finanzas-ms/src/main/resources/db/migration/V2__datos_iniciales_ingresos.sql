INSERT INTO ingresos (monto, descripcion) VALUES (50000.0, 'Saldo inicial de caja chica');
INSERT INTO ingresos (monto, descripcion) VALUES (12500.0, 'Venta menor de cuadernos');