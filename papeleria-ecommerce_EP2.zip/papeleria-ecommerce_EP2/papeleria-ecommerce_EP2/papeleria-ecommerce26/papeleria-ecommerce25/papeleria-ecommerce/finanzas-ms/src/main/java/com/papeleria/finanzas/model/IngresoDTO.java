package com.papeleria.finanzas.model;

public class IngresoDTO {
    private Double monto;
    private String descripcion;

    public IngresoDTO() {}

    // Getters y Setters
    public Double getMonto() { return monto; }
    public void setMonto(Double monto) { this.monto = monto; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}