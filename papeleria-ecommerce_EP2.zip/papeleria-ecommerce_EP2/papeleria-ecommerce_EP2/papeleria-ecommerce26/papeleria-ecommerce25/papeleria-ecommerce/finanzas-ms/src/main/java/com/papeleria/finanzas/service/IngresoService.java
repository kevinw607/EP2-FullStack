package com.papeleria.finanzas.service;

import com.papeleria.finanzas.entity.Ingreso;
import com.papeleria.finanzas.model.IngresoDTO;
import com.papeleria.finanzas.repository.IngresoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngresoService {

    private final IngresoRepository ingresoRepository;

    public IngresoService(IngresoRepository ingresoRepository) {
        this.ingresoRepository = ingresoRepository;
    }

    public List<Ingreso> obtenerTodos() {
        return ingresoRepository.findAll();
    }

    public Ingreso registrarIngreso(IngresoDTO ingresoDTO) {

        if (ingresoDTO.getMonto() == null || ingresoDTO.getMonto() <= 0) {
            throw new IllegalArgumentException("El monto del ingreso debe ser mayor a cero");
        }


        Ingreso ingreso = new Ingreso();
        ingreso.setMonto(ingresoDTO.getMonto());
        ingreso.setDescripcion(ingresoDTO.getDescripcion());

        return ingresoRepository.save(ingreso);
    }
}