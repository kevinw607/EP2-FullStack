CREATE TABLE notificaciones (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      destinatario VARCHAR(100) NOT NULL,
      mensaje VARCHAR(255) NOT NULL,
      enviado_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);