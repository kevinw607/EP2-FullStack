package com.papeleria.seguridad.config;

public class SecurityConfig {
}
