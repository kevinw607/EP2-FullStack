package com.papeleria.seguridad.exception;

public class GlobalExceptionHandler {
}
