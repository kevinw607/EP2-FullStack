package com.papeleria.seguridad.dto;

@Data
public class ResponseDTO {

    private String respuestaText;

    private Integer respuestaInteger;

}