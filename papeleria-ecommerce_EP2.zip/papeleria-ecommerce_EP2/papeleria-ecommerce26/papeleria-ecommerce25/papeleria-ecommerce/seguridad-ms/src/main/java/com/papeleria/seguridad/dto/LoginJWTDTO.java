package com.papeleria.seguridad.dto;

@Data
public class LoginJWTDTO {

    private String username;

    private String password;

}
