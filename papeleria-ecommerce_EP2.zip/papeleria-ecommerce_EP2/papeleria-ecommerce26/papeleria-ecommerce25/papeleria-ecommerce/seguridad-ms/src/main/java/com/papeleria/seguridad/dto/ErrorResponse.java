package com.papeleria.seguridad.dto;

@Data
public class ErrorResponse {

    private String mensaje;

    private String detalle;

    private int status;

    private LocalDateTime timeStamp;

}
